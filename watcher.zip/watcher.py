"""
Lambda Watcher
Trigger : S3 Event — flatfiles/inbox/*.txt
Job     : Parse flat file HEADER → create DynamoDB entry (edi_sent_status=N)
"""

import os
import logging
import urllib.parse
from datetime import datetime, timezone

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3       = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table    = dynamodb.Table(os.environ["DYNAMODB_TABLE"])


def lambda_handler(event, context):
    logger.info(f"S3 event received: {event}")

    for record in event.get("Records", []):
        process_record(record)

    return {"status": "ok"}


def process_record(record: dict):
    # ── Get S3 file details from event ──────────────────────
    bucket    = record["s3"]["bucket"]["name"]
    raw_key   = record["s3"]["object"]["key"]
    s3_key    = urllib.parse.unquote_plus(raw_key)
    file_name = s3_key.split("/")[-1]

    logger.info(f"New file detected: {file_name}")

    # ── Skip if already registered (safety guard) ───────────
    if already_exists(file_name):
        logger.warning(f"Skipping — {file_name} already in DynamoDB")
        return

    # ── Read flat file from S3 ───────────────────────────────
    response    = s3.get_object(Bucket=bucket, Key=s3_key)
    content     = response["Body"].read().decode("utf-8")

    # ── Parse HEADER line ────────────────────────────────────
    po = parse_header(content, file_name)

    # ── Write DynamoDB entry ─────────────────────────────────
    item = {
        "file_name":       file_name,
        "po_number":       po["po_number"],
        "supplier_id":     po["supplier_id"],
        "supplier_name":   po["supplier_name"],
        "po_date":         po["po_date"],
        "line_count":      po["line_count"],
        "created_date":    datetime.now(timezone.utc).isoformat(),
        "edi_sent_status": "N",
        "s3_flat_file_key": s3_key,
        "s3_edi_key":      None,
        "processed_date":  None,
    }

    table.put_item(Item=item)
    logger.info(f"DynamoDB entry created — po_number: {po['po_number']}, status: N")


def parse_header(content: str, file_name: str) -> dict:
    """
    Parse flat file and extract PO metadata.

    HEADER|583921|TESLA001|Tesla Inc|20240315
    ITEM|583921|MDL-Y-LR|Tesla Model Y Long Range AWD|5|EA
    TRAILER|583921|5
    """
    lines      = [l.strip() for l in content.strip().splitlines() if l.strip()]
    header     = None
    item_count = 0

    for line in lines:
        parts = line.split("|")
        tag   = parts[0].upper()

        if tag == "HEADER":
            header = parts
        elif tag == "ITEM":
            item_count += 1

    if not header or len(header) < 5:
        raise ValueError(f"Invalid or missing HEADER line in {file_name}")

    return {
        "po_number":    header[1].strip(),
        "supplier_id":  header[2].strip(),
        "supplier_name": header[3].strip(),
        "po_date":      header[4].strip(),
        "line_count":   item_count,
    }


def already_exists(file_name: str) -> bool:
    """Prevent duplicate entries if S3 event fires twice."""
    resp = table.get_item(Key={"file_name": file_name})
    return "Item" in resp